package com.lawrence.kafka.entity;

public record Author(String id, String name, String personalName) {
}
