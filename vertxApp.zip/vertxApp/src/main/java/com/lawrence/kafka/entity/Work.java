package com.lawrence.kafka.entity;

public record Work(String author, String cover, String title, String work) {
}
